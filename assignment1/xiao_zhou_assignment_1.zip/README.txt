Usage
nearest_neighbor.py input_<size>.txt

note: you can delete brute force method from line 112 to 117 to just see the divide and conquer method

compiled on windows 10 with python 3.5.2 (v3.5.2:4def2a2901a5, Jun 25 2016, 22:01:18) [MSC v.1900 32 bit (Intel)]
